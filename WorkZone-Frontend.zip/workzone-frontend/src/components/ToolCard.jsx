import { Link } from "react-router-dom";
import { ArrowUpRight, Star } from "lucide-react";

export default function ToolCard({ tool }) {
  return (
    <Link to={tool.path || "/tools"} className="tool-card">
      <div className="tool-icon">{tool.icon}</div>
      <div className="tool-content">
        <div className="tool-top">
          <span className="tool-category">{tool.category}</span>
          {tool.premium && <span className="premium-badge">PRO</span>}
        </div>
        <h3>{tool.name}</h3>
        <p>{tool.description}</p>
        <div className="tool-footer">
          <span><Star size={14} /> {tool.rating || "4.9"}</span>
          <span className="tool-open">Open <ArrowUpRight size={15} /></span>
        </div>
      </div>
    </Link>
  );
}