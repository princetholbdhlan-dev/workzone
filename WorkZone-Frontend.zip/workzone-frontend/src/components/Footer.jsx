import { Link } from "react-router-dom";
import { Mail, Twitter, Linkedin, Github } from "lucide-react";

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div>
          <Link to="/" className="brand footer-brand">
            <span className="brand-mark">✦</span>
            <span>Work<span>Zone</span></span>
          </Link>
          <p className="footer-text">
            One powerful workspace for freelancers to write, convert, clean,
            analyze and organize work faster.
          </p>
          <div className="socials">
            <a href="#twitter" aria-label="Twitter"><Twitter size={17} /></a>
            <a href="#linkedin" aria-label="LinkedIn"><Linkedin size={17} /></a>
            <a href="#github" aria-label="GitHub"><Github size={17} /></a>
            <a href="mailto:hello@workzone.app" aria-label="Email"><Mail size={17} /></a>
          </div>
        </div>

        <div>
          <h4>Product</h4>
          <Link to="/tools">All Tools</Link>
          <Link to="/categories">Categories</Link>
          <Link to="/pricing">Pricing</Link>
          <Link to="/dashboard">Dashboard</Link>
        </div>

        <div>
          <h4>Company</h4>
          <Link to="/about">About</Link>
          <Link to="/contact">Contact</Link>
          <a href="#privacy">Privacy Policy</a>
          <a href="#terms">Terms</a>
        </div>

        <div>
          <h4>Categories</h4>
          <a href="#pdf">PDF Tools</a>
          <a href="#image">Image Tools</a>
          <a href="#text">Text & Content</a>
          <a href="#developer">Developer Tools</a>
        </div>
      </div>

      <div className="container footer-bottom">
        <span>© 2026 WorkZone. All rights reserved.</span>
        <span>Built for freelancers.</span>
      </div>
    </footer>
  );
}