import { useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { Menu, X, Sun, Moon, Sparkles } from "lucide-react";

export default function Navbar({ dark, setDark }) {
  const [open, setOpen] = useState(false);

  const links = [
    ["Home", "/"],
    ["Tools", "/tools"],
    ["Categories", "/categories"],
    ["Pricing", "/pricing"],
    ["About", "/about"],
    ["Contact", "/contact"]
  ];

  return (
    <header className="navbar">
      <div className="container nav-inner">
        <Link to="/" className="brand" onClick={() => setOpen(false)}>
          <span className="brand-mark"><Sparkles size={18} /></span>
          <span>Work<span>Zone</span></span>
        </Link>

        <nav className={`nav-links ${open ? "show" : ""}`}>
          {links.map(([label, path]) => (
            <NavLink
              key={path}
              to={path}
              className={({ isActive }) => isActive ? "active" : ""}
              onClick={() => setOpen(false)}
            >
              {label}
            </NavLink>
          ))}
          <Link className="nav-login mobile-only" to="/login" onClick={() => setOpen(false)}>Login</Link>
          <Link className="btn btn-primary mobile-only" to="/register" onClick={() => setOpen(false)}>Get Started</Link>
        </nav>

        <div className="nav-actions">
          <button className="icon-btn" onClick={() => setDark(!dark)} aria-label="Toggle theme">
            {dark ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          <Link className="nav-login desktop-only" to="/login">Login</Link>
          <Link className="btn btn-primary desktop-only" to="/register">Get Started</Link>
          <button className="menu-btn" onClick={() => setOpen(!open)} aria-label="Menu">
            {open ? <X /> : <Menu />}
          </button>
        </div>
      </div>
    </header>
  );
}