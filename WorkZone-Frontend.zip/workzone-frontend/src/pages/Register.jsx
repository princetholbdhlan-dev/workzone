import { Link, useNavigate } from "react-router-dom";
import { AuthLayout } from "./Login";

export default function Register() {
  const navigate = useNavigate();
  return <AuthLayout title="Create your account" text="Start using WorkZone for your everyday freelance tasks.">
    <form onSubmit={e => {e.preventDefault(); navigate("/dashboard")}}>
      <label>Full name<input required placeholder="Your name"/></label>
      <label>Email<input type="email" required placeholder="you@example.com"/></label>
      <label>Password<input type="password" required minLength="6" placeholder="At least 6 characters"/></label>
      <label className="check"><input type="checkbox" required/> I agree to the Terms and Privacy Policy</label>
      <button className="btn btn-primary full">Create Account</button>
      <p className="auth-switch">Already have an account? <Link to="/login">Login</Link></p>
    </form>
  </AuthLayout>;
}