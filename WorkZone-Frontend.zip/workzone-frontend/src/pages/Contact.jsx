import { useState } from "react";
import { Mail, MessageSquare, Send } from "lucide-react";
import Footer from "../components/Footer";

export default function Contact() {
  const [sent, setSent] = useState(false);
  return <>
    <section className="page-hero"><div className="container"><span className="eyebrow">Contact</span><h1>How can we help?</h1><p>Send a message about support, bugs, partnerships or feature ideas.</p></div></section>
    <section className="section"><div className="container contact-grid"><div className="contact-info"><div className="info-card"><Mail/><h3>Email</h3><p>hello@workzone.app</p></div><div className="info-card"><MessageSquare/><h3>Feature requests</h3><p>Tell us which workflow you want to make faster.</p></div></div><form className="form-card" onSubmit={e => {e.preventDefault(); setSent(true)}}><label>Name<input required placeholder="Your name"/></label><label>Email<input required type="email" placeholder="you@example.com"/></label><label>Message<textarea required rows="6" placeholder="Tell us what you need..."/></label><button className="btn btn-primary full" type="submit">{sent ? "Message Sent ✓" : <>Send Message <Send size={16}/></>}</button></form></div></section>
    <Footer />
  </>;
}