import { Link } from "react-router-dom";
import { ArrowRight, Clock3, FileCheck2, FolderKanban, Search, Star, Upload } from "lucide-react";
import ToolCard from "../components/ToolCard";
import { tools } from "../data/tools";

export default function Dashboard() {
  const recent = tools.slice(0, 3);
  return <section className="dashboard-page"><div className="container">
    <div className="dashboard-head"><div><span className="eyebrow">Workspace</span><h1>Welcome back 👋</h1><p>Pick up where you left off.</p></div><Link className="btn btn-primary" to="/tools">Explore Tools <ArrowRight size={17}/></Link></div>
    <div className="stats-grid"><Stat icon={<FolderKanban/>} value="8" label="Projects"/><Stat icon={<FileCheck2/>} value="156" label="Files processed"/><Stat icon={<Clock3/>} value="24" label="Tools used"/><Stat icon={<Star/>} value="7" label="Favorites"/></div>
    <div className="dashboard-layout"><div><div className="dash-section-head"><h2>Recent tools</h2><Link to="/tools">View all</Link></div><div className="tools-grid compact">{recent.map(t => <ToolCard key={t.name} tool={t}/>)}</div></div><aside className="dash-side"><div className="side-card"><h3>Quick actions</h3><Link to="/tools"><Search size={17}/> Find a tool</Link><a href="#upload"><Upload size={17}/> Upload file</a><Link to="/settings"><FolderKanban size={17}/> Manage workspace</Link></div><div className="side-card usage"><h3>Free usage</h3><div className="progress"><span style={{width:"42%"}}/></div><p>42 / 100 actions used</p><Link to="/pricing">Upgrade plan <ArrowRight size={14}/></Link></div></aside></div>
  </div></section>;
}
function Stat({icon,value,label}) { return <div className="stat-card"><div>{icon}</div><strong>{value}</strong><span>{label}</span></div>; }