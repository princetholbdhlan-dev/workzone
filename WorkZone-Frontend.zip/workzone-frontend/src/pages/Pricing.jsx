import { Check } from "lucide-react";
import Footer from "../components/Footer";

const plans = [
  { name: "Free", price: "$0", text: "For trying WorkZone and everyday tasks.", features: ["Core utility tools", "Basic processing", "Limited daily usage", "Personal workspace"], button: "Start Free" },
  { name: "Pro", price: "$9", text: "For freelancers who use tools every day.", features: ["All free tools", "Higher usage limits", "Larger file limits", "Projects & templates", "Priority processing"], button: "Choose Pro", popular: true },
  { name: "Business", price: "$29", text: "For teams and advanced workflows.", features: ["Everything in Pro", "Team workspace", "API access", "Advanced limits", "Usage analytics"], button: "Choose Business" }
];

export default function Pricing() {
  return <>
    <section className="page-hero"><div className="container"><span className="eyebrow">Simple pricing</span><h1>Plans that scale with your work.</h1><p>Start free. Upgrade when your workflow needs more.</p></div></section>
    <section className="section"><div className="container pricing-grid">{plans.map(p => <div className={`price-card ${p.popular ? "popular" : ""}`} key={p.name}>{p.popular && <div className="popular-label">Most flexible</div>}<h2>{p.name}</h2><p>{p.text}</p><div className="price">{p.price}<small>{p.price !== "$0" ? "/month" : "/forever"}</small></div><button className={`btn ${p.popular ? "btn-primary" : "btn-secondary"} full`}>{p.button}</button><ul>{p.features.map(f => <li key={f}><Check size={16}/>{f}</li>)}</ul></div>)}</div></section>
    <Footer />
  </>;
}