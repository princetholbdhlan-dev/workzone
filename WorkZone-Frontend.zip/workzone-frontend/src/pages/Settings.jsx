import { useState } from "react";
import { Save } from "lucide-react";

export default function Settings() {
  const [saved, setSaved] = useState(false);
  return <section className="section settings-page"><div className="container narrow"><div className="page-heading"><span className="eyebrow">Account</span><h1>Settings</h1><p>Manage your profile and workspace preferences.</p></div><div className="settings-card"><h2>Profile</h2><label>Full name<input defaultValue="WorkZone User"/></label><label>Email<input defaultValue="user@example.com" type="email"/></label><label>Bio<textarea rows="4" placeholder="Tell us a little about yourself"/></label><button className="btn btn-primary" onClick={() => setSaved(true)}><Save size={16}/>{saved ? "Saved" : "Save Changes"}</button></div><div className="settings-card"><h2>Preferences</h2><label className="toggle"><input type="checkbox" defaultChecked/><span>Show recently used tools</span></label><label className="toggle"><input type="checkbox" defaultChecked/><span>Save tool history</span></label></div></div></section>;
}