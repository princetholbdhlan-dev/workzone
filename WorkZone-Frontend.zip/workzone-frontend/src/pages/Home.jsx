import { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Check, Clock3, ShieldCheck, Zap, Search, Sparkles } from "lucide-react";
import ToolCard from "../components/ToolCard";
import SectionTitle from "../components/SectionTitle";
import Footer from "../components/Footer";
import { tools, categories } from "../data/tools";

export default function Home() {
  const [query, setQuery] = useState("");
  const popular = tools.slice(0, 8);
  const filtered = popular.filter(t =>
    t.name.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <>
      <section className="hero">
        <div className="hero-glow glow-one" />
        <div className="hero-glow glow-two" />
        <div className="container hero-content">
          <div className="hero-badge"><Sparkles size={14} /> The freelancer super toolkit</div>
          <h1>Finish freelance work <span>in minutes.</span></h1>
          <p>
            WorkZone brings powerful tools for PDFs, images, content, data,
            SEO and development into one simple workspace.
          </p>
          <div className="hero-actions">
            <Link to="/tools" className="btn btn-primary btn-lg">Explore Tools <ArrowRight size={18} /></Link>
            <Link to="/register" className="btn btn-secondary btn-lg">Create Free Account</Link>
          </div>
          <div className="hero-trust">
            <span><Check size={15} /> Free tools available</span>
            <span><Check size={15} /> No complicated setup</span>
            <span><Check size={15} /> Built for freelancers</span>
          </div>
        </div>
      </section>

      <section className="search-section">
        <div className="container">
          <div className="tool-search">
            <Search size={20} />
            <input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="What do you need to do? Try “compress PDF”..."
            />
            <kbd>⌘ K</kbd>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <SectionTitle
            eyebrow="Popular tools"
            title="Everything you need, in one place"
            text="Start with the tools freelancers use every day."
          />
          <div className="tools-grid">
            {(query ? filtered : popular).map(tool => <ToolCard key={tool.name} tool={tool} />)}
          </div>
          {query && filtered.length === 0 && <div className="empty-state">No tools found for “{query}”.</div>}
          <div className="center-action"><Link to="/tools" className="text-link">View all tools <ArrowRight size={16} /></Link></div>
        </div>
      </section>

      <section className="section section-muted">
        <div className="container">
          <SectionTitle center eyebrow="Categories" title="One platform. Every freelance workflow." text="Organize your work around the tasks you actually do." />
          <div className="category-grid">
            {categories.map(cat => (
              <Link className="category-card" key={cat.name} to="/categories">
                <div className="category-icon">{cat.icon}</div>
                <div><h3>{cat.name}</h3><p>{cat.count}+ tools</p></div>
                <ArrowRight size={17} />
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container workflow-grid">
          <div>
            <span className="eyebrow">How it works</span>
            <h2>Less switching. More doing.</h2>
            <p className="lead">WorkZone turns repetitive freelance tasks into quick, repeatable workflows.</p>
            <div className="feature-list">
              <div><span>01</span><div><h3>Pick a tool</h3><p>Find the exact tool you need from the global toolkit.</p></div></div>
              <div><span>02</span><div><h3>Upload or enter</h3><p>Add your file, text, data or project details.</p></div></div>
              <div><span>03</span><div><h3>Process & download</h3><p>Get your result and continue with your client work.</p></div></div>
            </div>
          </div>
          <div className="workflow-panel">
            <div className="mini-window">
              <div className="window-top"><span /><span /><span /></div>
              <div className="mini-content">
                <div className="mini-label">IMAGE COMPRESSOR</div>
                <h3>Reduce file size</h3>
                <div className="upload-box"><ImageIconPlaceholder /> Drop your image here</div>
                <button className="btn btn-primary full">Compress Image <Zap size={16} /></button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section section-muted">
        <div className="container">
          <SectionTitle center eyebrow="Why WorkZone" title="Built around your time" text="Simple tools, clear interfaces and a workspace that scales with you." />
          <div className="benefits-grid">
            <Benefit icon={<Zap />} title="Fast workflows" text="Finish repetitive tasks without jumping between websites." />
            <Benefit icon={<ShieldCheck />} title="Privacy focused" text="Designed with secure processing and temporary file handling in mind." />
            <Benefit icon={<Clock3 />} title="Save time" text="Favorites, history and projects keep your most-used work close." />
          </div>
        </div>
      </section>

      <section className="cta-section">
        <div className="container cta-box">
          <div><span className="eyebrow">Ready to work smarter?</span><h2>Your freelance toolkit starts here.</h2><p>Create a free account and make WorkZone your everyday workspace.</p></div>
          <Link to="/register" className="btn btn-primary btn-lg">Get Started <ArrowRight size={18} /></Link>
        </div>
      </section>

      <Footer />
    </>
  );
}

function Benefit({ icon, title, text }) {
  return <div className="benefit-card"><div className="benefit-icon">{icon}</div><h3>{title}</h3><p>{text}</p></div>;
}

function ImageIconPlaceholder() {
  return <div className="placeholder-file">IMG</div>;
}