import { useState } from "react";
import { Search, SlidersHorizontal } from "lucide-react";
import ToolCard from "../components/ToolCard";
import SectionTitle from "../components/SectionTitle";
import Footer from "../components/Footer";
import { tools } from "../data/tools";

export default function Tools() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");

  const cats = ["All", ...new Set(tools.map(t => t.category))];
  const filtered = tools.filter(t =>
    (category === "All" || t.category === category) &&
    `${t.name} ${t.description}`.toLowerCase().includes(query.toLowerCase())
  );

  return <>
    <section className="page-hero"><div className="container"><span className="eyebrow">WorkZone toolkit</span><h1>All tools</h1><p>Find the right tool and get your work done faster.</p></div></section>
    <section className="section">
      <div className="container">
        <div className="filter-bar">
          <div className="tool-search small"><Search size={18}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search tools..." /></div>
          <div className="category-filters"><SlidersHorizontal size={17}/>{cats.map(c => <button key={c} className={category === c ? "selected" : ""} onClick={() => setCategory(c)}>{c}</button>)}</div>
        </div>
        <div className="tools-grid">{filtered.map(tool => <ToolCard key={tool.name} tool={tool} />)}</div>
        {!filtered.length && <div className="empty-state">No matching tools found.</div>}
      </div>
    </section>
    <Footer />
  </>;
}