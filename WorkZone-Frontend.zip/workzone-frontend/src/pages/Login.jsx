import { Link, useNavigate } from "react-router-dom";
import { Sparkles } from "lucide-react";

export default function Login() {
  const navigate = useNavigate();
  return <AuthLayout title="Welcome back" text="Sign in to continue your WorkZone workspace.">
    <form onSubmit={e => {e.preventDefault(); navigate("/dashboard")}}>
      <label>Email<input type="email" required placeholder="you@example.com"/></label>
      <label>Password<input type="password" required placeholder="••••••••"/></label>
      <div className="form-row"><label className="check"><input type="checkbox"/> Remember me</label><a href="#forgot">Forgot password?</a></div>
      <button className="btn btn-primary full">Login</button>
      <p className="auth-switch">Don't have an account? <Link to="/register">Create one</Link></p>
    </form>
  </AuthLayout>;
}

export function AuthLayout({ title, text, children }) {
  return <section className="auth-page"><div className="auth-box"><Link to="/" className="brand auth-brand"><span className="brand-mark"><Sparkles size={18}/></span>Work<span>Zone</span></Link><h1>{title}</h1><p>{text}</p>{children}</div></section>;
}