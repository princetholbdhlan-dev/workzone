import { Target, Users, Zap } from "lucide-react";
import Footer from "../components/Footer";

export default function About() {
  return <>
    <section className="page-hero"><div className="container"><span className="eyebrow">About WorkZone</span><h1>A simpler way to get freelance work done.</h1><p>WorkZone is designed as a single productivity platform for the repetitive tasks that slow freelancers down.</p></div></section>
    <section className="section"><div className="container about-grid"><div><span className="eyebrow">Our mission</span><h2>Give freelancers their time back.</h2><p className="lead">Instead of opening a different website for every small task, WorkZone brings useful tools together in one focused workspace.</p><p>Our roadmap covers file utilities, content, data, SEO, developer workflows and freelancer business tools.</p></div><div className="about-cards"><Info icon={<Target/>} title="Focused" text="Tools built around real freelance workflows."/><Info icon={<Users/>} title="Freelancer-first" text="Simple interfaces without unnecessary complexity."/><Info icon={<Zap/>} title="Practical" text="Designed to turn repetitive work into quick actions."/></div></div></section>
    <Footer />
  </>;
}
function Info({icon,title,text}) { return <div className="info-card"><div className="benefit-icon">{icon}</div><h3>{title}</h3><p>{text}</p></div>; }