import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import SectionTitle from "../components/SectionTitle";
import Footer from "../components/Footer";
import { categories } from "../data/tools";

export default function Categories() {
  return <>
    <section className="page-hero"><div className="container"><span className="eyebrow">Explore</span><h1>Tool categories</h1><p>Everything organized around common freelancer workflows.</p></div></section>
    <section className="section"><div className="container"><SectionTitle title="Choose a category" text="Browse tools by the kind of work you need to complete." /><div className="category-large-grid">{categories.map(cat => <Link className="category-large-card" key={cat.name} to="/tools"><div className="category-icon">{cat.icon}</div><div><h3>{cat.name}</h3><p>{cat.count}+ tools available</p></div><ArrowRight /></Link>)}</div></div></section>
    <Footer />
  </>;
}