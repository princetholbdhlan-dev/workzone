import {
  FileText, Image, Braces, Database, Search, ReceiptText,
  FileStack, Type, Scissors, FileImage, Code2, Sparkles
} from "lucide-react";

export const tools = [
  { name: "Image Compressor", category: "Image", description: "Reduce image size while keeping quality.", icon: <Image />, path: "/tools/image-compressor" },
  { name: "Image Resizer", category: "Image", description: "Resize images to exact dimensions in seconds.", icon: <Image />, path: "/tools/image-resizer" },
  { name: "Image Converter", category: "Image", description: "Convert JPG, PNG and WebP formats easily.", icon: <FileImage />, path: "/tools/image-converter" },
  { name: "PDF Merger", category: "PDF", description: "Combine multiple PDF files into one document.", icon: <FileStack />, path: "/tools/pdf-merger" },
  { name: "PDF Splitter", category: "PDF", description: "Extract selected pages from a PDF.", icon: <Scissors />, path: "/tools/pdf-splitter" },
  { name: "PDF Compressor", category: "PDF", description: "Make PDF files smaller and easier to share.", icon: <FileText />, path: "/tools/pdf-compressor" },
  { name: "Word Counter", category: "Text", description: "Count words, characters and sentences instantly.", icon: <Type />, path: "/tools/word-counter" },
  { name: "Case Converter", category: "Text", description: "Transform text into upper, lower or title case.", icon: <Type />, path: "/tools/case-converter" },
  { name: "JSON Formatter", category: "Developer", description: "Format and validate JSON with a clean interface.", icon: <Braces />, path: "/tools/json-formatter" },
  { name: "CSV Cleaner", category: "Data", description: "Clean, validate and organize CSV data.", icon: <Database />, path: "/tools/csv-cleaner" },
  { name: "SEO Title Generator", category: "SEO", description: "Create search-friendly titles for your content.", icon: <Search />, premium: true, path: "/tools/seo-title-generator" },
  { name: "Invoice Generator", category: "Freelancer", description: "Create professional invoices in minutes.", icon: <ReceiptText />, path: "/tools/invoice-generator" },
  { name: "AI Rewriter", category: "AI", description: "Rewrite content into a clearer, more polished version.", icon: <Sparkles />, premium: true, path: "/tools/ai-rewriter" },
  { name: "HTML Formatter", category: "Developer", description: "Beautify and organize HTML code.", icon: <Code2 />, path: "/tools/html-formatter" }
];

export const categories = [
  { name: "PDF Tools", count: 10, icon: <FileText />, id: "pdf" },
  { name: "Image Tools", count: 10, icon: <Image />, id: "image" },
  { name: "Text & Content", count: 14, icon: <Type />, id: "text" },
  { name: "Data & Excel", count: 10, icon: <Database />, id: "data" },
  { name: "SEO Tools", count: 9, icon: <Search />, id: "seo" },
  { name: "Developer Tools", count: 15, icon: <Code2 />, id: "developer" },
  { name: "Freelancer Tools", count: 10, icon: <ReceiptText />, id: "freelancer" },
  { name: "AI Tools", count: 8, icon: <Sparkles />, id: "ai" }
];